<?php
/**
 * Register the milestone widget.  This makes it easier to keep the /milestone/ dir content in sync with wpcom.
 */
include dirname( __FILE__ ) . '/milestone/milestone.php';
